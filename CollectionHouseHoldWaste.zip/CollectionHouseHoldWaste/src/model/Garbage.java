package model;

public class Garbage {
    private int kgGarbage;

    public Garbage() {

    }

    public Garbage(int n) {
        this.kgGarbage = n;
    }

    public int getGarbage() {
        return kgGarbage;
    }

    public void setGarbage(int n) {
        this.kgGarbage = n;
    }

    public int getNumberGarbage() {
        return kgGarbage;
    }

    public void setNumberGarbage(int numberGarbage) {
        this.kgGarbage = numberGarbage;
    }


}
