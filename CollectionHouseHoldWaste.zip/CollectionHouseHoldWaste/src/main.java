import controller.Program;

public class main {
    public static void main(String[] args) {
        Program pr = new Program();
        pr.run();
        //1765 2808 952 4206 3102 3902 1292 3985 8324 1928 4426 397 3277
    }
}